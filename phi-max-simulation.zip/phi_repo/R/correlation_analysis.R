# =============================================================================
# correlation_analysis.R
#
# Reproduces the inter-component correlation results reported in Section 3.4
# of:
#   Kara, R. (2026). Design Principles for Composite P-Hacking Detection
#   Indices with Complementary Components: A Monte Carlo Simulation Study.
#   Submitted to Journal of Statistical Computation and Simulation.
#
# This script depends only on base R (no external packages required) and runs
# on the labelled simulation grid (n = 44,000 synthetic studies) provided as
# data/sim_grid_results.csv.
#
# Outputs:
#   - Console output covering Table 4 Panel A and Panel B, Table 5, and the
#     selective-outcome operational equivalence verification (Section 3.4.3).
#   - Three CSV files written to the current working directory:
#       corr_pooled_pearson.csv
#       corr_pooled_spearman.csv
#       corr_by_condition.csv
#
# Run time: < 5 seconds on a standard laptop.
#
# Usage:
#   1) Set the working directory to the repository root.
#   2) source("R/correlation_analysis.R")
# =============================================================================

# -----------------------------------------------------------------------------
# Load the labelled simulation grid
# -----------------------------------------------------------------------------
DATA_PATH <- "data/sim_grid_results.csv"

if (!file.exists(DATA_PATH)) {
  stop("Could not find ", DATA_PATH,
       ". Set the working directory to the repository root, or adjust DATA_PATH.")
}

sim <- read.csv(DATA_PATH, stringsAsFactors = FALSE)

cat("Loaded simulation grid:", nrow(sim), "rows x", ncol(sim), "cols\n\n")

# Mid-rank-standardised component columns (recommended composite inputs;
# see Sections 2.6 and 3.3 of the manuscript).
COMP <- c("pcurve_mr", "tiva_mr", "caliper_mr")

# -----------------------------------------------------------------------------
# Section 3.4.1 — Pooled correlations (Table 4 Panel A)
# -----------------------------------------------------------------------------
cat("============================================================\n")
cat("Section 3.4.1 - Pooled correlations (n = ", nrow(sim), ")\n", sep = "")
cat("Table 4 Panel A\n")
cat("============================================================\n\n")

pooled_pearson  <- cor(sim[, COMP], method = "pearson")
pooled_spearman <- cor(sim[, COMP], method = "spearman")

cat("Pearson:\n")
print(round(pooled_pearson, 3))

cat("\nSpearman:\n")
print(round(pooled_spearman, 3))

write.csv(round(pooled_pearson,  4), "corr_pooled_pearson.csv")
write.csv(round(pooled_spearman, 4), "corr_pooled_spearman.csv")

# -----------------------------------------------------------------------------
# Section 3.4.1 — Within-strategy-family correlations (Table 4 Panel B)
# -----------------------------------------------------------------------------
cat("\n\n============================================================\n")
cat("Section 3.4.1 - Within-strategy-family correlations (Pearson)\n")
cat("Table 4 Panel B\n")
cat("============================================================\n")

# Group definitions (all severities pooled within each strategy family).
groups <- list(
  "Clean"             = sim$strategy == "clean",
  "Opt.Stop pooled"   = sim$strategy == "optstop",
  "Min-p Sel+Out"     = sim$strategy %in% c("selective", "outcome")
)

for (name in names(groups)) {
  subset <- sim[groups[[name]], COMP]
  cat(sprintf("\n%s (n = %d):\n", name, nrow(subset)))
  print(round(cor(subset, method = "pearson"), 3))
}

# -----------------------------------------------------------------------------
# Section 3.4.2 — Within-condition correlations (Table 5)
# -----------------------------------------------------------------------------
cat("\n\n============================================================\n")
cat("Section 3.4.2 - Within-condition Pearson correlations\n")
cat("Table 5 (11 conditions x 3 component pairs)\n")
cat("============================================================\n")

# Logical condition order for tabular presentation in the manuscript.
cond_order <- c(
  "clean_null", "clean_mixed",
  "optstop_low", "optstop_med", "optstop_high",
  "sel_low",     "sel_med",     "sel_high",
  "out_low",     "out_med",     "out_high"
)

cond_corrs <- data.frame(
  condition       = character(),
  n               = integer(),
  pcurve_tiva     = numeric(),
  pcurve_caliper  = numeric(),
  tiva_caliper    = numeric(),
  stringsAsFactors = FALSE
)

for (cond in cond_order) {
  subset <- sim[sim$condition == cond, ]
  if (nrow(subset) == 0) next
  cm <- cor(subset[, COMP], method = "pearson")
  cond_corrs <- rbind(cond_corrs, data.frame(
    condition       = cond,
    n               = nrow(subset),
    pcurve_tiva     = round(cm["pcurve_mr", "tiva_mr"],    3),
    pcurve_caliper  = round(cm["pcurve_mr", "caliper_mr"], 3),
    tiva_caliper    = round(cm["tiva_mr",   "caliper_mr"], 3)
  ))
}

cat("\n")
print(cond_corrs, row.names = FALSE)

write.csv(cond_corrs, "corr_by_condition.csv", row.names = FALSE)

# -----------------------------------------------------------------------------
# Section 3.4.2 — Summary statistics across the 33 within-condition correlations
# -----------------------------------------------------------------------------
all_r <- with(cond_corrs,
              c(abs(pcurve_tiva), abs(pcurve_caliper), abs(tiva_caliper)))

cat("\n--- Summary across 33 within-condition pairwise |r| values ---\n")
cat(sprintf("  Min  |r| = %.3f\n", min(all_r)))
cat(sprintf("  Mean |r| = %.3f\n", mean(all_r)))
cat(sprintf("  Max  |r| = %.3f\n", max(all_r)))
cat(sprintf("  |r| < 0.30 : %d / %d\n", sum(all_r < 0.30), length(all_r)))
cat(sprintf("  |r| < 0.50 : %d / %d\n", sum(all_r < 0.50), length(all_r)))

# -----------------------------------------------------------------------------
# Section 3.4.3 — Numerical confirmation of selective-outcome equivalence
# -----------------------------------------------------------------------------
cat("\n\n============================================================\n")
cat("Section 3.4.3 - Selective vs Outcome operational equivalence\n")
cat("============================================================\n")

severities <- c("low", "med", "high")
pairs      <- c("pcurve_tiva", "pcurve_caliper", "tiva_caliper")

eq_check <- data.frame(
  severity = character(),
  pair     = character(),
  r_sel    = numeric(),
  r_out    = numeric(),
  abs_diff = numeric(),
  stringsAsFactors = FALSE
)

for (sev in severities) {
  sel_row <- cond_corrs[cond_corrs$condition == paste0("sel_", sev), ]
  out_row <- cond_corrs[cond_corrs$condition == paste0("out_", sev), ]
  if (nrow(sel_row) == 0 || nrow(out_row) == 0) next
  for (pair in pairs) {
    r_sel <- sel_row[[pair]]
    r_out <- out_row[[pair]]
    eq_check <- rbind(eq_check, data.frame(
      severity = sev,
      pair     = pair,
      r_sel    = r_sel,
      r_out    = r_out,
      abs_diff = abs(r_sel - r_out)
    ))
  }
}

cat("\n")
print(eq_check, row.names = FALSE)

cat(sprintf(
  "\nMaximum absolute difference across %d comparisons: %.3f\n",
  nrow(eq_check), max(eq_check$abs_diff)
))
cat(sprintf("Mean   absolute difference: %.3f\n", mean(eq_check$abs_diff)))

cat("\n--- Output files written to working directory: ---\n")
cat("  corr_pooled_pearson.csv\n")
cat("  corr_pooled_spearman.csv\n")
cat("  corr_by_condition.csv\n")

cat("\nDone.\n")
